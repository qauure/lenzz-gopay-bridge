<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
function reply(int $code, array $data): void { http_response_code($code); echo json_encode($data); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(405,['ok'=>false,'error'=>'method_not_allowed']);
$cfgFile=__DIR__.'/gopay-bridge-config.php';
if (!is_file($cfgFile)) reply(503,['ok'=>false,'error'=>'bridge_not_configured']);
$cfg=require $cfgFile;
$auth=$_SERVER['HTTP_AUTHORIZATION'] ?? '';
$expected='Bearer '.($cfg['token'] ?? '');
if (($cfg['token'] ?? '')==='' || !hash_equals($expected,$auth)) reply(401,['ok'=>false,'error'=>'unauthorized']);
$raw=file_get_contents('php://input');
$data=json_decode($raw,true);
if (!is_array($data)) reply(400,['ok'=>false,'error'=>'invalid_json']);
$amount=(string)($data['amount'] ?? '');
if ($amount!=='' && !preg_match('/^[0-9]{1,12}$/',$amount)) reply(400,['ok'=>false,'error'=>'invalid_amount']);
$record=[
 'received_at'=>gmdate('c'),
 'source'=>'android_notification',
 'package'=>substr((string)($data['package'] ?? ''),0,160),
 'text'=>substr((string)($data['text'] ?? ''),0,1500),
 'amount'=>$amount,
 'posted_at'=>(int)($data['posted_at'] ?? 0),
 'notification_key'=>substr((string)($data['notification_key'] ?? ''),0,250),
 'verification'=>'PENDING_ADMIN_REVIEW'
];
$dir=__DIR__.'/private';
if (!is_dir($dir) && !mkdir($dir,0700,true)) reply(500,['ok'=>false,'error'=>'storage_failed']);
$file=$dir.'/notifications.jsonl';
$line=json_encode($record,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
$fp=fopen($file,'ab');
if (!$fp) reply(500,['ok'=>false,'error'=>'storage_failed']);
flock($fp,LOCK_EX); fwrite($fp,$line.PHP_EOL); fflush($fp); flock($fp,LOCK_UN); fclose($fp);
reply(200,['ok'=>true,'verification'=>'PENDING_ADMIN_REVIEW']);
