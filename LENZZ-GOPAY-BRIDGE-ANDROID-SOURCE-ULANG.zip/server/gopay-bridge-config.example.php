<?php
// Salin menjadi gopay-bridge-config.php dan isi token acak panjang.
// Jangan gunakan token yang sama dengan password admin.
return ['token' => 'GANTI_DENGAN_TOKEN_ACAK_PANJANG_MINIMAL_40_KARAKTER'];
