LENZZ GoPay Bridge - SOURCE AND SERVER RECEIVER

PENTING:
- Paket ini adalah SOURCE PROJECT Android Studio, bukan APK siap install.
- Aplikasi hanya meneruskan isi notifikasi GoPay Merchant yang cocok dengan filter.
- Notifikasi dapat dipalsukan/diulang dan tidak memiliki bukti kriptografis. Endpoint hanya menyimpan sebagai PENDING_ADMIN_REVIEW.
- JANGAN gunakan notifikasi ini untuk menambah saldo otomatis. Cocokkan transaksi pada aplikasi/laporan resmi GoPay Merchant.
- QRIS statis tidak bisa dibuat menjadi QRIS dinamis oleh aplikasi ini. Pembuatan tagihan QR dinamis memerlukan API resmi acquirer.

SERVER:
1. Upload server/gopay-bridge.php ke folder web LENZZ STORE.
2. Salin gopay-bridge-config.example.php menjadi gopay-bridge-config.php.
3. Ganti token dengan string acak panjang. Jangan bagikan token.
4. Pastikan folder server/private hanya dapat diakses PHP; .htaccess disediakan.
5. URL endpoint adalah https://DOMAIN/gopay-bridge.php (sesuaikan lokasi file).
6. Uji endpoint dengan data dummy, cek server/private/notifications.jsonl. Jangan hubungkan ke auto-credit.

ANDROID:
1. Buka folder ini dengan Android Studio.
2. Build > Build APK(s), lalu install APK debug pada HP Android.
3. Buka aplikasi, isi URL endpoint dan token yang sama.
4. Simpan, lalu aktifkan akses notifikasi pada pengaturan Android.
5. Pastikan aplikasi GoPay Merchant mengirim notifikasi pembayaran.
6. Jaga aplikasi dan token; matikan akses notifikasi jika tidak lagi digunakan.

Privasi:
Notification Listener Android memiliki akses membaca notifikasi perangkat. Aktifkan hanya pada perangkat merchant dan jangan gunakan untuk membaca aplikasi lain.
