package id.lenzz.gopaybridge;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.*;

public class GoPayNotificationListener extends NotificationListenerService {
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg=sbn.getPackageName();
        // Batasi hanya paket GoPay Merchant. Verifikasi nama paket dapat disesuaikan jika aplikasi resmi mengganti ID.
        if(pkg==null || !(pkg.toLowerCase().contains("merchant") || pkg.toLowerCase().contains("gopay"))) return;
        Notification n=sbn.getNotification(); if(n==null || n.extras==null) return;
        Bundle e=n.extras;
        String title=String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE,""));
        String body=String.valueOf(e.getCharSequence(Notification.EXTRA_TEXT,""));
        String big=String.valueOf(e.getCharSequence(Notification.EXTRA_BIG_TEXT,""));
        String text=(title+" "+body+" "+big).trim();
        if(!text.toLowerCase().contains("pembayaran") && !text.toLowerCase().contains("qris")) return;
        String amount="";
        Matcher m=Pattern.compile("(?i)Rp\\s*([0-9][0-9.,]*)").matcher(text);
        if(m.find()) amount=m.group(1).replace(".","").replace(",","");
        final String finalAmount=amount, finalText=text, finalPkg=pkg;
        executor.execute(()->send(finalPkg,finalText,finalAmount,sbn.getPostTime()));
    }
    private void send(String pkg,String text,String amount,long postedAt) {
        SharedPreferences p=getSharedPreferences("bridge",0);
        String endpoint=p.getString("endpoint",""), token=p.getString("token","");
        if(endpoint.isEmpty() || token.isEmpty()) return;
        HttpURLConnection c=null;
        try {
            JSONObject j=new JSONObject();
            j.put("source","android_notification"); j.put("package",pkg);
            j.put("title","GoPay Merchant notification"); j.put("text",text);
            j.put("amount",amount); j.put("posted_at",postedAt);
            j.put("notification_key",pkg+":"+postedAt+":"+amount);
            c=(HttpURLConnection)new URL(endpoint).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(10000); c.setReadTimeout(10000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            c.setRequestProperty("Authorization","Bearer "+token);
            byte[] data=j.toString().getBytes(StandardCharsets.UTF_8);
            try(OutputStream os=c.getOutputStream()){os.write(data);}
            c.getResponseCode();
        } catch(Exception ignored) { }
        finally { if(c!=null)c.disconnect(); }
    }
}
