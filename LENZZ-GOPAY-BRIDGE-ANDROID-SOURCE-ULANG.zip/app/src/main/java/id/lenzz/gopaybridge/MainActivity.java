package id.lenzz.gopaybridge;

import android.app.*;
import android.os.*;
import android.content.*;
import android.provider.Settings;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    EditText endpoint, token;
    TextView status;
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,28,28,28);
        TextView title=new TextView(this); title.setText("LENZZ GoPay Bridge"); title.setTextSize(24); root.addView(title);
        TextView desc=new TextView(this); desc.setText("Penghubung notifikasi GoPay Merchant ke server LENZZ. Hanya notifikasi GoPay Merchant yang diproses."); desc.setPadding(0,12,0,18); root.addView(desc);
        endpoint=new EditText(this); endpoint.setHint("URL endpoint, contoh https://domain.com/gopay-bridge.php"); endpoint.setSingleLine(); root.addView(endpoint);
        token=new EditText(this); token.setHint("Token penghubung (sama dengan token di server)"); token.setSingleLine(); root.addView(token);
        Button save=new Button(this); save.setText("Simpan Pengaturan"); root.addView(save);
        Button perm=new Button(this); perm.setText("Aktifkan Izin Akses Notifikasi"); root.addView(perm);
        status=new TextView(this); status.setPadding(0,20,0,0); root.addView(status);
        setContentView(root);
        android.content.SharedPreferences p=getSharedPreferences("bridge",0);
        endpoint.setText(p.getString("endpoint","")); token.setText(p.getString("token",""));
        save.setOnClickListener(v->{p.edit().putString("endpoint",endpoint.getText().toString().trim()).putString("token",token.getText().toString().trim()).apply(); status.setText("Pengaturan tersimpan.");});
        perm.setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));});
        status.setText("Izin notifikasi: "+(isEnabled()?"Aktif":"Belum aktif"));
    }
    boolean isEnabled() {
        String enabled=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        return enabled!=null && enabled.contains(getPackageName());
    }
}
